let items = [];

function addItem() {
  const name = document.getElementById('itemName').value;
  const stock = document.getElementById('itemStock').value;
  const category = document.getElementById('itemCategory').value;

  if (!name || !stock || !category) {
    alert("Lengkapi semua field.");
    return;
  }

  items.push({ name, stock, category });
  renderTable();
  document.getElementById('itemName').value = '';
  document.getElementById('itemStock').value = '';
  document.getElementById('itemCategory').value = '';
}

function renderTable() {
  const table = document.getElementById('itemTable');
  table.innerHTML = '';
  items.forEach((item, index) => {
    table.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${item.name}</td>
        <td>${item.stock}</td>
        <td>${item.category}</td>
        <td><button onclick="deleteItem(${index})">Hapus</button></td>
      </tr>`;
  });
}

function deleteItem(index) {
  items.splice(index, 1);
  renderTable();
}

function searchItem() {
  const query = document.getElementById('searchBox').value.toLowerCase();
  const table = document.getElementById('itemTable');
  const filtered = items.filter(item => item.name.toLowerCase().includes(query));
  table.innerHTML = '';
  filtered.forEach((item, index) => {
    table.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${item.name}</td>
        <td>${item.stock}</td>
        <td>${item.category}</td>
        <td><button onclick="deleteItem(${index})">Hapus</button></td>
      </tr>`;
  });
}
