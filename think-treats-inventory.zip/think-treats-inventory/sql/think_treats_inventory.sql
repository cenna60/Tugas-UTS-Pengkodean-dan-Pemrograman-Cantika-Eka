CREATE DATABASE IF NOT EXISTS think_treats_inventory;
USE think_treats_inventory;

CREATE TABLE IF NOT EXISTS inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    quantity INT,
    price DECIMAL(10,2),
    supplier VARCHAR(100),
    purchase_date DATE
);