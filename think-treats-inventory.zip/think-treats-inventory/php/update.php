<?php
$koneksi = mysqli_connect("localhost", "root", "", "think_treats_inventory");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tangkap JSON body
    $data = json_decode(file_get_contents('php://input'), true);

    // Ambil data dari JSON
    $id = $data['id'];
    $name = $data['name'];
    $category = $data['category'];
    $quantity = $data['quantity'];
    $price = preg_replace('/[^0-9]/', '', $data['price']); // bersihkan format harga
    $supplier = $data['supplier'];
    $purchase_date = $data['purchase_date'];

    $query = "UPDATE inventory SET 
                name='$name', 
                category='$category', 
                quantity='$quantity', 
                price='$price', 
                supplier='$supplier', 
                purchase_date='$purchase_date' 
              WHERE id='$id'";

    if (mysqli_query($koneksi, $query)) {
        echo json_encode(["status" => "success", "message" => "Data berhasil diupdate"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal update data: " . mysqli_error($koneksi)]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>
