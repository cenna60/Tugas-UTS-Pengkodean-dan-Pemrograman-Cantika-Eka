<?php
$conn = new mysqli("localhost", "root", "", "think_treats_inventory");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>