<?php
$koneksi = mysqli_connect("localhost", "root", "", "think_treats_inventory");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$query = "SELECT * FROM inventory";
$result = mysqli_query($koneksi, $query);

$items = [];

while ($row = mysqli_fetch_assoc($result)) {
    $items[] = [
        "id" => $row['id'],
        "name" => htmlspecialchars($row['name']),
        "category" => htmlspecialchars($row['category']),
        "quantity" => $row['quantity'],
        "price" => $row['price'],
        "supplier" => htmlspecialchars($row['supplier']),
        "purchase_date" => $row['purchase_date']
    ];
}

header('Content-Type: application/json');
echo json_encode($items);
?>
