<?php
$koneksi = mysqli_connect("localhost", "root", "", "think_treats_inventory");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Tangkap data JSON dari body
$data = json_decode(file_get_contents("php://input"), true);

// Pastikan data ada
if ($data) {
    $name = mysqli_real_escape_string($koneksi, $data['name']);
    $category = mysqli_real_escape_string($koneksi, $data['category']);
    $quantity = (int) $data['quantity'];
    $price = preg_replace('/[^0-9]/', '', $data['price']); // hanya angka
    $supplier = mysqli_real_escape_string($koneksi, $data['supplier']);
    $purchase_date = mysqli_real_escape_string($koneksi, $data['purchase_date']);

    $query = "INSERT INTO inventory (name, category, quantity, price, supplier, purchase_date) 
              VALUES ('$name', '$category', '$quantity', '$price', '$supplier', '$purchase_date')";

    if (mysqli_query($koneksi, $query)) {
        echo "Berhasil";
    } else {
        echo "Gagal: " . mysqli_error($koneksi);
    }
} else {
    echo "Data tidak valid";
}
?>
