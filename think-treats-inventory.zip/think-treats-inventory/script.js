document.addEventListener("DOMContentLoaded", () => {
    loadInventory();

    document.getElementById("inventoryForm").addEventListener("submit", (e) => {
        e.preventDefault();
        const data = {
            name: document.getElementById("name").value,
            category: document.getElementById("category").value,
            quantity: document.getElementById("quantity").value,
            price: document.getElementById("price").value.replace(/[^0-9]/g, ''), // pastikan angka saja
            supplier: document.getElementById("supplier").value,
            purchase_date: document.getElementById("purchase_date").value,
        };

        fetch("php/insert.php", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.text())
        .then(response => {
            alert(response); // tampilkan pesan "Berhasil" atau "Gagal"
            loadInventory();
            e.target.reset();
        });
    });
});

function loadInventory() {
    fetch("php/fetch.php")
        .then(res => res.json())
        .then(data => {
            const tableBody = document.getElementById("tableBody");
            tableBody.innerHTML = "";
            data.forEach((item, index) => {
                const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td class="hidden">${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.category}</td>
                    <td>${item.quantity}</td>
                    <td>Rp ${Number(item.price).toLocaleString('id-ID')}</td>
                    <td>${item.supplier}</td>
                    <td>${item.purchase_date}</td>
                    <td>
                        <button class="btn-action" onclick="editItem(this)">Edit</button>
                        <button class="btn-action" onclick="deleteItem(this)">Hapus</button>
                    </td>
                </tr>
                `;
                tableBody.innerHTML += row;
            });
        }); // <--- tambahin tutup sini buat .then()
} 		
function editItem(button) {
    const row = button.closest('tr');
    const id = row.children[1].innerText; // hidden id
    const name = row.children[2].innerText;
    const category = row.children[3].innerText;
    const quantity = row.children[4].innerText;
    const price = row.children[5].innerText;
    const supplier = row.children[6].innerText;
    const purchase_date = row.children[7].innerText;

    // Isi form edit seperti biasa...
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editCategory').value = category;
    document.getElementById('editQuantity').value = quantity;
    document.getElementById('editPrice').value = price;
    document.getElementById('editSupplier').value = supplier;
    document.getElementById('editPurchaseDate').value = purchase_date;

    document.getElementById('editModal').style.display = 'flex';
}

function deleteItem(button) {
    const row = button.closest('tr');
    const id = row.children[1].innerText; // hidden id
    if (confirm("Yakin ingin menghapus data ini?")) {
        fetch(`php/delete.php?id=${id}`)
            .then(res => res.text())
            .then(response => {
                alert(response);
                loadInventory();
            });
    }
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('editId').value;
    const name = document.getElementById('editName').value;
    const category = document.getElementById('editCategory').value;
    const quantity = document.getElementById('editQuantity').value;
    const price = document.getElementById('editPrice').value;
    const supplier = document.getElementById('editSupplier').value;
    const purchase_date = document.getElementById('editPurchaseDate').value;

    fetch("php/update.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, name, category, quantity, price, supplier, purchase_date })
    })
    .then(res => res.text())
    .then((response) => {
        console.log(response);
        closeModal();
        loadInventory();
    })
    .catch(error => console.error('Error:', error));
});

// Format harga saat input
document.getElementById('price').addEventListener('input', function(e) {
    let value = e.target.value.replace(/[^0-9]/g, '');
    e.target.value = formatRupiah(value);
});

// Format harga di tabel setelah data dimuat
function formatTablePrices() {
    const priceCells = document.querySelectorAll('#tableBody td:nth-child(5)');
    priceCells.forEach(cell => {
        let value = cell.textContent.trim();
        if(!value.startsWith('Rp')) {
            cell.textContent = formatRupiah(value);
        }
    });
}

function formatRupiah(angka) {
    let number_string = angka.replace(/[^,\d]/g, '').toString();
    let split = number_string.split(',');
    let sisa = split[0].length % 3;
    let rupiah = split[0].substr(0, sisa);
    let ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
        let separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
    return rupiah ? 'Rp ' + rupiah : '';
}